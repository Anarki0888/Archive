/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thedupuy <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/10 18:57:53 by thedupuy          #+#    #+#             */
/*   Updated: 2016/07/10 18:58:26 by thedupuy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_sec(char a, char b, char c, int y);

void	colle(int x, int y)
{
	int i;

	i = 0;
	if (x > 0 && y > 0)
	{
		ft_sec('A', 'B', 'A', x);
		if (y > 2)
		{
			while (i < (y - 2))
			{
				ft_sec('B', ' ', 'B', x);
				i++;
			}
		}
		if (y > 1)
		{
			ft_sec('C', 'B', 'C', x);
		}
	}
}

void	ft_sec(char a, char b, char c, int y)
{
	int i;

	i = 0;
	ft_putchar(a);
	while (i < (y - 2))
	{
		ft_putchar(b);
		i++;
	}
	if (y > 1)
	{
		ft_putchar(c);
	}
	ft_putchar('\n');
}
