/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thedupuy <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/07/09 15:57:59 by thedupuy          #+#    #+#             */
/*   Updated: 2016/07/09 15:58:53 by thedupuy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

int		ft_atoi(char *str)
{
	int result;
	int len;
	int negative;

	result = 0;
	len = 0;
	negative = 0;
	if (*str == '\0')
		return (0);
	while (str[len] == ' ' || str[len] == '\r' || str[len] == '\f'
		|| str[len] == '\n' || str[len] == '\t' || str[len] == '\v')
		len++;
	if (str[len] == '-')
		negative = 1;
	if (str[len] == '-' || str[len] == '+')
		len++;
	while ((str[len] >= '0') && (str[len] <= '9') && (str[len] != '\0'))
	{
		result = result * 10 + (str[len] - '0');
		len++;
	}
	if (negative == 1)
		result = result * -1;
	return (result);
}

void	colle(int x, int y);

int		main(int argc, char **argv)
{
	if (argc > 1)
	{
		if (argc == 3)
			colle(ft_atoi(argv[1]), ft_atoi(argv[2]));
		else
			write(1, "This program need two arguments.\n", 33);
	}
	else
		colle(5, 2);
	return (0);
}
